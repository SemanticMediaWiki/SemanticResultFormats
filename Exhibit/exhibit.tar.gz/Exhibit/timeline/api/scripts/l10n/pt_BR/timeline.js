/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["pt_BR"] = {
    wikiLinkLabel:  "Discutir"
};


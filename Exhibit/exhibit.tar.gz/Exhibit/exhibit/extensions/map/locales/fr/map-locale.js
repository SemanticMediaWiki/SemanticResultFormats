﻿/*==================================================
 *  Exhibit Map Extension French localization
 *==================================================
 */

if (!("l10n" in Exhibit.MapView)) {
    Exhibit.MapView.l10n = {};
}

Exhibit.MapView.l10n.viewLabel = "Carte";
Exhibit.MapView.l10n.viewTooltip = "Voir les items sur une carte";

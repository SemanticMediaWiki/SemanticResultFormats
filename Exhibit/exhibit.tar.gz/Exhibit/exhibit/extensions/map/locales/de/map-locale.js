/*==================================================
 *  Exhibit Map Extension German localization
 *==================================================
 */

if (!("l10n" in Exhibit.MapView)) {
    Exhibit.MapView.l10n = {};
}

Exhibit.MapView.l10n.viewLabel = "Landkarte";
Exhibit.MapView.l10n.viewTooltip = "Zeige diese Elemente auf einer Landkarte";

/*==================================================
 *  Exhibit Map Extension English localization
 *==================================================
 */

if (!("l10n" in Exhibit.MapView)) {
    Exhibit.MapView.l10n = {};
}

Exhibit.MapView.l10n.viewLabel = "Map";
Exhibit.MapView.l10n.viewTooltip = "View items on a map";

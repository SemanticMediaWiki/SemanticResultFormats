/*==================================================
 *  Exhibit Map Extension English localization
 *==================================================
 */

if (!("l10n" in Exhibit.MapView)) {
    Exhibit.MapView.l10n = {};
}

Exhibit.MapView.l10n.viewLabel = "Kaart";
Exhibit.MapView.l10n.viewTooltip = "Bekijk items met een kaart";

/*==================================================
 *  Exhibit Time Extension English localization
 *==================================================
 */

if (!("l10n" in Exhibit.TimelineView)) {
    Exhibit.TimelineView.l10n = {};
}

Exhibit.TimelineView.l10n.viewLabel = "Timeline";
Exhibit.TimelineView.l10n.viewTooltip = "View items on a timeline";

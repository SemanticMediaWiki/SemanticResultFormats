﻿/*==================================================
 *  Exhibit Time Extension French localization
 *==================================================
 */

if (!("l10n" in Exhibit.TimelineView)) {
    Exhibit.TimelineView.l10n = {};
}

Exhibit.TimelineView.l10n.viewLabel = "Ligne de temps";
Exhibit.TimelineView.l10n.viewTooltip = "Voir les items sur une ligne de temps";

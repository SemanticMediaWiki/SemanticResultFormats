/*==================================================
 *  Exhibit Time Extension German localization
 *==================================================
 */

if (!("l10n" in Exhibit.TimelineView)) {
    Exhibit.TimelineView.l10n = {};
}

Exhibit.TimelineView.l10n.viewLabel = "Zeitleiste";
Exhibit.TimelineView.l10n.viewTooltip = "Zeige diese Elemente auf einer Zeitleiste";

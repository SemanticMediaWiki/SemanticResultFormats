/*==================================================
 *  Exhibit Time Extension Dutch localization
 *==================================================
 */

if (!("l10n" in Exhibit.TimelineView)) {
    Exhibit.TimelineView.l10n = {};
}

Exhibit.TimelineView.l10n.viewLabel = "Tijdlijn";
Exhibit.TimelineView.l10n.viewTooltip = "Bekijk items op een tijdlijn";

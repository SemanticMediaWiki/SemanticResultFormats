﻿/*==================================================
 *  Exhibit Time Extension Swedish localization
 *==================================================
 */

if (!("l10n" in Exhibit.TimelineView)) {
    Exhibit.TimelineView.l10n = {};
}

Exhibit.TimelineView.l10n.viewLabel = "Tidslinje";
Exhibit.TimelineView.l10n.viewTooltip = "Visa på tidslinje";

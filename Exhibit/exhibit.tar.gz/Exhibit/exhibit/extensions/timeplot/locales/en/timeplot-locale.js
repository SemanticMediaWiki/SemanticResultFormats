/*==================================================
 *  Exhibit Timeplot Extension English localization
 *==================================================
 */

if (!("l10n" in Exhibit.TimeplotView)) {
    Exhibit.TimeplotView.l10n = {};
}

Exhibit.TimeplotView.l10n.viewLabel = "Timeplot";
Exhibit.TimeplotView.l10n.viewTooltip = "View items on a timeplot";

/*==================================================
 *  Exhibit Timeplot Extension Dutch localization
 *==================================================
 */

if (!("l10n" in Exhibit.TimeplotView)) {
    Exhibit.TimeplotView.l10n = {};
}

Exhibit.TimeplotView.l10n.viewLabel = "Grafiek";
Exhibit.TimeplotView.l10n.viewTooltip = "Bekijk items op een grafiek";

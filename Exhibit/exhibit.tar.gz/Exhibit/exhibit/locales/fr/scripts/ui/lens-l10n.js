/*==================================================
 *  Exhibit.Lens French localization
 *==================================================
 */

if (!("l10n" in Exhibit.Lens)) {
    Exhibit.Lens.l10n = {};
}

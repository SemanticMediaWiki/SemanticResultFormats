/*==================================================
 *  Exhibit.Coders German localization
 *==================================================
 */

if (!("l10n" in Exhibit.Coders)) {
    Exhibit.Coders.l10n = {};
}

Exhibit.Coders.l10n.mixedCaseLabel = "gemischt";
Exhibit.Coders.l10n.missingCaseLabel = "fehlend";
Exhibit.Coders.l10n.othersCaseLabel = "andere";

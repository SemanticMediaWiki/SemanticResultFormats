/*==================================================
 *  Exhibit.ThumbnailView Norwegian localization
 *==================================================
 */

if (!("l10n" in Exhibit.ThumbnailView)) {
    Exhibit.ThumbnailView.l10n = {};
}

Exhibit.ThumbnailView.l10n.viewLabel = "Miniatyrbilder";
Exhibit.ThumbnailView.l10n.viewTooltip = "Vis som miniatyrbilder";

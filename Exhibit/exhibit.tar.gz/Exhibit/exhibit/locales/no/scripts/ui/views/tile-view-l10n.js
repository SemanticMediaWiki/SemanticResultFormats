/*==================================================
 *  Exhibit.TileView Norwegian localization
 *==================================================
 */

if (!("l10n" in Exhibit.TileView)) {
    Exhibit.TileView.l10n = {};
}

Exhibit.TileView.l10n.viewLabel = "Liste";
Exhibit.TileView.l10n.viewTooltip = "Vis som liste ";

/*==================================================
 *  Exhibit.Coders Norwegian localization
 *==================================================
 */

if (!("l10n" in Exhibit.Coders)) {
    Exhibit.Coders.l10n = {};
}

Exhibit.Coders.l10n.mixedCaseLabel = "blandet";
Exhibit.Coders.l10n.missingCaseLabel = "mangler";
Exhibit.Coders.l10n.othersCaseLabel = "andre";

/*==================================================
 *  Exhibit.TileView Dutch localization
 *==================================================
 */

if (!("l10n" in Exhibit.TileView)) {
    Exhibit.TileView.l10n = {};
}

Exhibit.TileView.l10n.viewLabel = "Tegels";
Exhibit.TileView.l10n.viewTooltip = "Toon items als tegels in een lijst";

/*==================================================
 *  Exhibit.ThumbnailView Dutch localization
 *==================================================
 */

if (!("l10n" in Exhibit.ThumbnailView)) {
    Exhibit.ThumbnailView.l10n = {};
}

Exhibit.ThumbnailView.l10n.viewLabel = "Miniaturen";
Exhibit.ThumbnailView.l10n.viewTooltip = "Toon items als miniaturen";

/*==================================================
 *  Exhibit.TileView Swedish localization
 *==================================================
 */

if (!("l10n" in Exhibit.TileView)) {
    Exhibit.TileView.l10n = {};
}

Exhibit.TileView.l10n.viewLabel = "Lista";
Exhibit.TileView.l10n.viewTooltip = "Visa som lista";

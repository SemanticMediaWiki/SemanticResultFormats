/*==================================================
 *  Exhibit.Lens Chinese localization
 *==================================================
 */

if (!("l10n" in Exhibit.Lens)) {
    Exhibit.Lens.l10n = {};
}
